http://d1oja7zqrpdrbf.cloudfront.net/index.html

Bucket website endpoint
http://my-udacity-cloud-dev-project1.s3-website.us-east-2.amazonaws.com/
